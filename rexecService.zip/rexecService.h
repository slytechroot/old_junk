// rexecService.h : main header file for the REXECSERVICE application
//

#if !defined(AFX_REXECSERVICE_H__1B1A1A43_299D_11D7_9DC6_000802875B8A__INCLUDED_)
#define AFX_REXECSERVICE_H__1B1A1A43_299D_11D7_9DC6_000802875B8A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include <afxsock.h>
#include <afxmt.h>
#include "NTService.h"
/////////////////////////////////////////////////////////////////////////////
// CRexecServiceApp:
// See rexecService.cpp for the implementation of this class
//

class CRexecServiceApp : public CWinApp, public CNTService  
{
public:
    CEvent* m_pStop;
	CRexecServiceApp();
	void Run(DWORD, LPTSTR *);
	void Stop();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRexecServiceApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CRexecServiceApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

inline CRexecServiceApp* GetApp() { return (CRexecServiceApp*)AfxGetApp(); }
/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REXECSERVICE_H__1B1A1A43_299D_11D7_9DC6_000802875B8A__INCLUDED_)
