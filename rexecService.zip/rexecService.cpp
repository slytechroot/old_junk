// Created by Tim Kohler
// This class is the implementation for the service.
// We define the run method as a simple one connection per 
// thread socket server.  The rexec process pumps command lines 
// to us and we execute them.  
//
// We also define the stop method to terminate the service.
//
// Note:  The CNTService class was created by Joerg Koenig and
//        modified by TODD C. WILSON.  

// rexecService.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "rexecService.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRexecServiceApp

BEGIN_MESSAGE_MAP(CRexecServiceApp, CWinApp)
	//{{AFX_MSG_MAP(CRexecServiceApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRexecServiceApp construction

CRexecServiceApp::CRexecServiceApp() :
   CNTService(TEXT("RemoteExecutionService"), TEXT("Remote Program Execution"))
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
	m_pStop = new CEvent(FALSE, TRUE); //manual reset event.
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CRexecServiceApp object

CRexecServiceApp theApp;


// Connection thread function:
UINT ProcConnectionFunc(LPVOID pParam)
{
   SOCKET hSock = SOCKET(pParam);
   CAsyncSocket CliSock;
   CliSock.Attach(hSock);

   CHAR pInData[1028];

   int nTotalBytes = 0;
   int nRec = 0;
   while (1)
   {
		int nRec = CliSock.Receive(&pInData[nTotalBytes], 1028 - nTotalBytes);
		if (nRec == SOCKET_ERROR || nRec == 0)
			break;
		if (GetApp()->m_pStop->Lock(0))
			break;

		nTotalBytes+=nRec;
   }

   CString strDta(pInData, nTotalBytes);

   STARTUPINFO         StartInfo;
   PROCESS_INFORMATION ProcInfo;

   memset(&StartInfo, 0, sizeof(STARTUPINFO));
   StartInfo.cb = sizeof(STARTUPINFO);
 
   CString strCmdLine = strDta; //set the command line.
      

   BOOL fOk = CreateProcess(NULL, strCmdLine.GetBuffer(0), NULL, NULL, FALSE, NORMAL_PRIORITY_CLASS, 
                             NULL, NULL, &StartInfo, &ProcInfo);
   
   CliSock.Close();

   return 1;
}


/////////////////////////////////////////////////////////////////////////////
// CRexecServiceApp initialization


BOOL CRexecServiceApp::InitInstance() 
{
	RegisterService(__argc, __argv);
	
	return FALSE;
}


void CRexecServiceApp::Run( DWORD argc, LPTSTR *argv) 
{		
   // args not used in this small example
	// report to the SCM that we're about to start
	ReportStatus(SERVICE_START_PENDING);
	
	// You might do some more initialization here.
	// Parameter processing for instance ...
	
	// report SERVICE_RUNNING immediately before you enter the main-loop
	// DON'T FORGET THIS!
	ReportStatus(SERVICE_RUNNING);

	if (!AfxSocketInit())
	{
		AfxMessageBox(IDP_SOCKETS_INIT_FAILED);
		return;
	}

	// enter main-loop
	// If the Stop() method sets the event, then we will break out of
	// this loop.
	// TODO: code your application's behavior here.

    CAsyncSocket SrvSock;
    SrvSock.Create(9987);
    SrvSock.Listen();
    CAsyncSocket CliSock;
    SOCKADDR addr;
    int nSize = sizeof(SOCKADDR);
    // Loop to maintain the search while the application is running.
    while (!m_pStop->Lock(0)) 
    {
       // Check to see if a connection is being attempted.
       if(SrvSock.Accept(CliSock, &addr, &nSize))
       { 
          SOCKET hSock = CliSock.m_hSocket;
          CliSock.Detach();
          //Let a seperate thread handle the individual connections:
          AfxBeginThread(ProcConnectionFunc, (LPVOID)hSock);
       }
       Sleep(1);
    }
    // Clean up...
    SrvSock.Close();
}


void CRexecServiceApp::Stop() 
{
	// report to the SCM that we're about to stop
	// Note that the service might Sleep(), so we have to tell
	// the SCM
	//	"The next operation may take up to 40 seconds. Please be patient."
	ReportStatus(SERVICE_STOP_PENDING, 40000);

	m_pStop->SetEvent();
}
