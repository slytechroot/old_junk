#include "stdafx.h"
#include "resource.h"

using namespace std;

// This function will extract one of the embedded PE files in this
// executable image and save it to disk.
bool SaveResource(WORD resId, wstring destPath)
{
	HRSRC hRes = FindResource(NULL, MAKEINTRESOURCE(resId), L"BIN");
	HGLOBAL hLoadedRes = LoadResource(NULL, hRes);

	char *pRes = static_cast<char*>(LockResource(hLoadedRes));
	DWORD dwResSize = SizeofResource(NULL, hRes);

	ofstream outstream(destPath.c_str(), ios::binary);
	if (!outstream)
		return false;

	outstream.write(pRes, dwResSize);
	outstream.close();
	return true;
}

int _tmain(int argc, wchar_t* argv[])
{
	string cinIgnore;

	cout << "RemoteUnlock by Dan Farino" << endl;

	if (argc != 2)
	{
		cout << "Usage: RemoteUnlock.exe machinename" << endl;
		return 0;
	}

	// Build the paths on the remote machine where we'll be copying the files too
	wstring destRoot = L"\\\\";
	destRoot.append(argv[1]);
	destRoot.append(L"\\admin$\\");

	wstring destSvcPath = destRoot + L"RemoteUnlockService.exe";
	wstring destDllPath = destRoot + L"RemoteUnlockDll.dll";

	// Extract the service EXE and DLL and save to the remote machine
	if (!SaveResource(IDR_SvcExe, destSvcPath) || !SaveResource(IDR_SvcDll, destDllPath))
	{
		cout << "ERROR: error writing files to remote machine" << endl;
		return 0;
	}

	// Connect to the Service Control Manager on the remote machine
	SC_HANDLE hSC = 0;
	SC_HANDLE hSvc = 0;
	SERVICE_STATUS svcStatus = { 0 };

	hSC = OpenSCManager(
		argv[1],
		NULL,
		GENERIC_ALL
		);

	if (!hSC)
	{
		cout << "ERROR: Couldn't connect to remote Service Control Manager: " << GetLastError() << endl;
		goto done;
	}

	// Create the service
	hSvc = CreateService(
		hSC,
		L"RemoteUnlockService",
		L"Remote Workstation Unlocker Service",
		SERVICE_ALL_ACCESS,
		SERVICE_WIN32_OWN_PROCESS,
		SERVICE_DEMAND_START,
		SERVICE_ERROR_NORMAL,
		L"%SystemRoot%\\RemoteUnlockService.exe",
		NULL,
		NULL,
		NULL,
		NULL,
		NULL
		);

	if (!hSvc)
	{
		cout << "ERROR: Couldn't create remote service: " << GetLastError() << endl;
		goto done;
	}

	// Start the remote service
	if (!StartService(hSvc, 0, NULL))
	{
		cout << "ERROR: Couldn't start remote service: " << GetLastError() << endl;
		goto done;
	}

	// Wait for the remote service to either start successfully or fail to start
	while (true)
	{
		if (!QueryServiceStatus(hSvc, &svcStatus))
		{
			cout << "ERROR: Failed to query remote service status: " << GetLastError() << endl;
			goto done;
		}

		if (svcStatus.dwCurrentState == SERVICE_RUNNING)
			break;

		if (svcStatus.dwCurrentState == SERVICE_STOPPED)
		{
			cout << "ERROR: Remote service did not start successfully: " << GetLastError() << endl;
			goto done;
		}

		Sleep(250);
	}

	cout << "Workstation should be unlocked. Hit ENTER to re-lock and quit." << endl;
	getline(cin, cinIgnore);

done:
	if (hSvc)
	{
		// Stop the remote service, which will re-lock the machine
		ControlService(hSvc, SERVICE_CONTROL_STOP, &svcStatus);
		while (true)
		{
			if (!QueryServiceStatus(hSvc, &svcStatus))
			{
				cout << "ERROR: Failed to query remote service status (during stop): " << GetLastError() << endl;
				break;
			}
		
			if (svcStatus.dwCurrentState == SERVICE_STOPPED)
				break;

			Sleep(250);
		}

		// Delete the remote service
		if (!DeleteService(hSvc))
			cout << "ERROR: Failed to delete remote service: " << GetLastError() << endl;

		CloseServiceHandle(hSvc);
	}

	if (hSC)
		CloseServiceHandle(hSC);

	// Delete the files we copied to the remote machine
	if (!DeleteFile(destSvcPath.c_str()))
		cout << "Error deleting service EXE: " << GetLastError() << endl;

	if (!DeleteFile(destDllPath.c_str()))
		cout << "Error deleting service DLL: " << GetLastError() << endl;

	return 0;
}

