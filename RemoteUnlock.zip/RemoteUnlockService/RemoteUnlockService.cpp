#include "stdafx.h"

using namespace std;

#define OUTPUT_DEBUG(msg) (::OutputDebugStringW((MAKE_STRING(msg)).c_str()))

SERVICE_STATUS ServiceStatus = { 0 };

HANDLE hDoneEvent = 0;
HANDLE hRelockEvent = 0;
HANDLE hSuccessEvent = 0;

DWORD WINAPI HandlerEx(DWORD dwControl, DWORD dwEventType, PVOID pvEventData, PVOID pvContext)
{
	if (dwControl == SERVICE_CONTROL_STOP || dwControl == SERVICE_CONTROL_SHUTDOWN)
	{
		// Setting this event will tell RemoteUnlockDll.dll to re-lock the workstation
		SetEvent(hDoneEvent);
		return NO_ERROR;
	}

	return ERROR_CALL_NOT_IMPLEMENTED;
}

bool InjectDll()
{
	LPVOID pRemoteVm = 0;
	HANDLE hWinLogon = 0;
	HANDLE hSnap = INVALID_HANDLE_VALUE;
	HANDLE hRemoteThread = 0;

	DWORD winlogonPid = 0;
	bool retval = false;

	// Build the pathname to RemoteUnlockDll.dll, which is %SYSTEMROOT%\RemoteUnlockDll.dll
	vector<wchar_t> buffer;
	buffer.resize(MAX_PATH);
	ExpandEnvironmentStringsW(L"%SYSTEMROOT%", &buffer[0], MAX_PATH);

	wstring dllPath(&buffer[0]);
	dllPath.append(L"\\RemoteUnlockDll.dll");

	// Get the ID of the console session. We'll need this to be able to locate the
	// proper winlogon process (we need the one running in the console session)
	DWORD consoleSessionId = WTSGetActiveConsoleSessionId();

	// Find the winlogon process
	PROCESSENTRY32 procEntry;

	hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	if (hSnap == INVALID_HANDLE_VALUE)
	{
		OUTPUT_DEBUG("RemoteUnlockService: CreateToolhelp32Snapshot failed" << endl);
		goto cleanup;
	}

	procEntry.dwSize = sizeof(PROCESSENTRY32);

	if (!Process32FirstW(hSnap, &procEntry))
	{
		OUTPUT_DEBUG("RemoteUnlockService: Process32FirstW failed" << endl);
		goto cleanup;
	}

	do
	{
		if (_wcsicmp(procEntry.szExeFile, L"winlogon.exe") == 0)
		{
			// We found a winlogon process...make sure it's running in the console session
			DWORD winlogonSessId = 0;
			if (ProcessIdToSessionId(procEntry.th32ProcessID, &winlogonSessId) && winlogonSessId == consoleSessionId)
			{
				winlogonPid = procEntry.th32ProcessID;
				break;
			}
		}

	} while (Process32NextW(hSnap, &procEntry));

	if (winlogonPid)
	{
		// Open a handle to the winlogon process
		hWinLogon = OpenProcess(
			PROCESS_CREATE_THREAD | PROCESS_VM_OPERATION | PROCESS_VM_WRITE,
			FALSE,
			winlogonPid
			);

		if (!hWinLogon)
			goto cleanup;

		// Calculate the size of the string we need to write into winlogon's address space.
		// We'll be writing the path to RemoteUnlockDll.dll because it will be used as the
		// parameter to our remote thread function (LoadLibraryW)
		size_t dllPathSize = static_cast<size_t>((dllPath.size() + 1) * sizeof(wchar_t));
		
		// Allocate some address space for the pathname in the winlogon process
		pRemoteVm = VirtualAllocEx(hWinLogon, NULL, dllPathSize, MEM_COMMIT, PAGE_READWRITE);
		if (!pRemoteVm)
		{
			OUTPUT_DEBUG("RemoteUnlockService: VirtualAllocEx failed" << endl);
			goto cleanup;
		}

		// Copy the DLL pathname into Winlogon.exe's address space
		if (!WriteProcessMemory(hWinLogon, pRemoteVm, dllPath.c_str(), dllPathSize, NULL))
		{
			OUTPUT_DEBUG("RemoteUnlockService: WriteProcessMemory failed" << endl);
			goto cleanup;
		}

		// Get the address for LoadLibraryW, which will be our thread function
		PTHREAD_START_ROUTINE pThreadStart = reinterpret_cast<PTHREAD_START_ROUTINE>(GetProcAddress(
			GetModuleHandleW(L"kernel32.dll"),
			"LoadLibraryW"
			));

		if (!pThreadStart)
		{
			OUTPUT_DEBUG("RemoteUnlockService: GetProcAddress failed" << endl);
			goto cleanup;
		}

		// And finally, kick of the thread in winlogon that will do our dirty work
		hRemoteThread = CreateRemoteThread(
			hWinLogon,
			NULL,
			0,
			pThreadStart,
			pRemoteVm,
			0,
			NULL
			);

		if (!hRemoteThread)
		{
			OUTPUT_DEBUG("RemoteUnlockService: CreateRemoteThread failed" << endl);
			goto cleanup;
		}

		// Wait for the thread to complete executing LoadLibraryW
		WaitForSingleObject(hRemoteThread, INFINITE);
		retval = true;

cleanup:
		if (hSnap != INVALID_HANDLE_VALUE)
			CloseHandle(hSnap);

		if (hRemoteThread)
			CloseHandle(hRemoteThread);

		if (pRemoteVm)
			VirtualFreeEx(hWinLogon, pRemoteVm, 0, MEM_RELEASE);

		if (hWinLogon)
			CloseHandle(hWinLogon);
	}

	return retval;
}

void WINAPI ServiceMain(DWORD dwArgc, LPWSTR *pszArgv)
{
	// Tell the Service Control Manager we're staring
	SERVICE_STATUS_HANDLE hSvcStatus = RegisterServiceCtrlHandlerExW(
		L"RemoteUnlockService",
		HandlerEx,
		NULL
		);

	ServiceStatus.dwServiceType = SERVICE_WIN32_OWN_PROCESS | SERVICE_INTERACTIVE_PROCESS;
	ServiceStatus.dwCurrentState = SERVICE_START_PENDING;
	ServiceStatus.dwControlsAccepted = SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_SHUTDOWN;
	ServiceStatus.dwWin32ExitCode = NO_ERROR;
	ServiceStatus.dwWaitHint = 2000;

	SetServiceStatus(hSvcStatus, &ServiceStatus);

	hDoneEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	hRelockEvent = CreateEvent(NULL, FALSE, FALSE, L"31D75C35-89A7-47ad-B28F-2A8B9F02B879");
	hSuccessEvent = CreateEvent(NULL, FALSE, FALSE, L"3BC12D0B-F71C-4e35-B1B1-3E6CE9EE189A");

	if (!hRelockEvent || !hDoneEvent || !hSuccessEvent)
	{
		OUTPUT_DEBUG("RemoteUnlockService: error creating events" << endl);
		goto stop;
	}

	// Inject the DLL into the winlogon process
	if (!InjectDll())
		goto stop;

	// Wait for RemoteUnlockDll.dll to tell us that everything worked. I haven't really
	// built a solid communication mechanism for error reporting, so we'll just wait 3 seconds
	// and if we haven't heard anything by then, we'll assume something failed.
	if (WaitForSingleObject(hSuccessEvent, 3000) != WAIT_OBJECT_0)
	{
		OUTPUT_DEBUG("RemoteUnlockService: DLL injection failed or workstation is not locked" << endl);
		goto stop;
	}

	// Tell the SCM we've started successfully. This will let RemoteUnlock.exe on the remote machine
	// know that the workstation should now be unlocked.
	ServiceStatus.dwCurrentState = SERVICE_RUNNING;
	SetServiceStatus(hSvcStatus, &ServiceStatus);

	// Wait for stop to be signalled by HandlerEx (above)
	WaitForSingleObject(hDoneEvent, INFINITE);

	// Tell RemoteUnlockDll.dll to re-lock the workstation and unload
	SetEvent(hRelockEvent);
	CloseHandle(hRelockEvent);

stop:
	CloseHandle(hDoneEvent);
	CloseHandle(hRelockEvent);
	CloseHandle(hSuccessEvent);

	ServiceStatus.dwCurrentState = SERVICE_STOPPED;
	SetServiceStatus(hSvcStatus, &ServiceStatus);
}

SERVICE_TABLE_ENTRY ServiceTable[] = {
	{ L"RemoteUnlockService", ServiceMain },
	{ NULL, NULL }
};

int main(int argc, wchar_t* argv[])
{
	StartServiceCtrlDispatcher(ServiceTable);
	return 0;
}
