#include "stdafx.h"

HMODULE g_hModule = 0; // The handle to this DLL

DWORD WINAPI ThreadProc(LPVOID lpParameter)
{
	HANDLE hRelockEvent = 0;
	HANDLE hSuccessEvent = 0;
	HDESK hNewDesktop = 0;
	HDESK hOriginalDesktop = 0;

	__try
	{
		// Open the event that RemoteUnlockService created to let us know when it's stopping
		hRelockEvent = OpenEvent(GENERIC_READ | SYNCHRONIZE, FALSE, L"31D75C35-89A7-47ad-B28F-2A8B9F02B879");
		if (!hRelockEvent)
		{
			OutputDebugStringW(L"OpenEvent failed (hRelockEvent)");
			__leave;
		}

		// Now open the event that we'll use to signal RemoteUnlockService that we've switched
		// desktops successfully
		hSuccessEvent = OpenEvent(GENERIC_READ | GENERIC_WRITE | SYNCHRONIZE, FALSE, L"3BC12D0B-F71C-4e35-B1B1-3E6CE9EE189A");
		if (!hSuccessEvent)
		{
			OutputDebugStringW(L"OpenEvent failed (hSuccessEvent)");
			__leave;
		}

		// Save the original desktop (which presumably is the "Winlogon" desktop)
		hOriginalDesktop = OpenInputDesktop(0, FALSE, GENERIC_READ | DESKTOP_SWITCHDESKTOP);
		if (!hOriginalDesktop)
		{
			OutputDebugStringW(L"OpenInputDesktop failed");
			__leave;
		}

		// Make sure the current desktop is indeed Winlogon
		wchar_t objNameBuffer[64];
		DWORD lengthNeeded = 0;
		if (!GetUserObjectInformation(hOriginalDesktop, UOI_NAME, &objNameBuffer[0], sizeof(objNameBuffer), &lengthNeeded))
		{
			OutputDebugStringW(L"GetUserObjectInformation failed");
			__leave;
		}

		if (_wcsicmp(objNameBuffer, L"winlogon") != 0)
		{
			OutputDebugStringW(L"Current desktop is not Winlogon");
			__leave;
		}

		// Get a handle to the desktop we want to switch to ("Default")
		hNewDesktop = OpenDesktop(L"Default", 0, FALSE, DESKTOP_SWITCHDESKTOP);
		if (!hNewDesktop)
		{
			OutputDebugStringW(L"OpenDesktop failed");
			__leave;
		}

		// Switch desktops
		if (!SwitchDesktop(hNewDesktop))
		{
			OutputDebugStringW(L"SwitchDesktop failed");
			__leave;
		}

		// Tell RemoteUnlockService we've switched desktops and are waiting for it
		// to tell us to switch back
		SetEvent(hSuccessEvent);
		WaitForSingleObject(hRelockEvent, INFINITE);
		SwitchDesktop(hOriginalDesktop);
	}
	__finally
	{
		if (hOriginalDesktop)
			CloseDesktop(hOriginalDesktop);

		if (hNewDesktop)
			CloseDesktop(hNewDesktop);

		if (hRelockEvent)
			CloseHandle(hRelockEvent);

		if (hSuccessEvent)
			CloseHandle(hSuccessEvent);
	}

	// Unload this module and terminate this thread
	FreeLibraryAndExitThread(g_hModule, 0);
	return 0;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
	if (ul_reason_for_call == DLL_PROCESS_ATTACH)
	{
		// Store the module handle for this DLL so we can unload it later
		g_hModule = hModule;

		// Create another thread so this thread can exit We can't do too much work
		// here in DllMain because we're holding the OS Loader lock.
		HANDLE hThread = CreateThread(
			NULL,
			0,
			&ThreadProc,
			NULL,
			0,
			NULL
			);

		// We don't need this handle, so close it to avoid a leak in Winlogon
		CloseHandle(hThread);
	}

    return TRUE;
}
