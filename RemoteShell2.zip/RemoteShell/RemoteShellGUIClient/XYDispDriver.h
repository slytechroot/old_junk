#ifndef XYDISPDRIVER_H
#define XYDISPDRIVER_H

// uncomment the following line if you are exporting the XYDispDriver class
// #define XYDISPDRIVER_BUILDDLL
// uncomment the following line if you are importing the XYDispDriver class
// #define XYDISPDRIVER_USEDLL
// uncomment the following line if you want to output debug messages
// #define XYDISPDRIVER_DEBUG

#ifdef XYDISPDRIVER_BUILDDLL
	#define XYDISPDRIVER_EXPORT __declspec(dllexport)
#else
	# ifdef XYDISPDRIVER_USEDLL
		#define XYDISPDRIVER_EXPORT __declspec(dllimport)
	#else
		#define XYDISPDRIVER_EXPORT 
	#endif
#endif

#include <windows.h>
#include <tchar.h>
#include <stdio.h>
#include <oaidl.h>


#define XYDISPDRIVER_OLENAMELEN 120


// XYDispInfo: private helper class to store type info of a method or a property
class XYDispInfo
{
	friend class XYDispDriver;
	XYDispInfo();
	~XYDispInfo();
	// dispatch id
	DISPID m_dispID;
	// method or property name
	BSTR m_bstrName;
	// invoke flag
	WORD m_wFlag;
	// output type
	VARTYPE m_vtOutputType;
	// output data
	VARIANT* m_pOutput;
	// number of parameters
	int m_nParamCount;
	// parameter type array
	BYTE* m_pParamTypes;
};

// XYDispDriver: the main class
class XYDISPDRIVER_EXPORT XYDispDriver
{
	// pointer to the IDispatch interface
	IDispatch* m_pDisp;
	// number of methods and properties
	int m_nDispInfoCount;
	// array of type info
	XYDispInfo* m_pDispInfo;
	// error return code
	HRESULT m_hRet;
	// exception info
	EXCEPINFO* m_pExceptInfo;
	// private helper functions
	int FindDispInfo(LPCTSTR strName, const WORD wFlag = DISPATCH_METHOD);
	HRESULT InvokeMethodV(const int nIndex, va_list argList);
	void Clear();
public:
	XYDispDriver();
	~XYDispDriver();
	// create a com object with given prog id
	bool CreateObject(LPCTSTR strProgID, DWORD dwClsContext = 1);
	// create a com object with given class id
	bool CreateObject(CLSID clsid,  DWORD dwClsContext = 1);
	// return the index of a property in the internal storage
	int FindProperty(LPCTSTR strPropertyName, const WORD wFlag = DISPATCH_PROPERTYGET);
	// return the index of a method in the internal storage
	int FindMethod(LPCTSTR strMethodName);
	// get the type of a property by name
	VARTYPE GetPropertyType(LPCTSTR strPropertyName);
	// get the type of a property by index
	VARTYPE GetPropertyType(int nPropertyIndex);
	// get a property value by name
	VARIANT* GetProperty(LPCTSTR strPropertyName);
	// get a property value by index
	VARIANT* GetProperty(int nPropertyIndex);
	// set a property value by name
	bool SetProperty(LPCTSTR strPropertyName, ...);
	// set a property value by index
	bool SetProperty(int nPropertyIndex, ...);
	// set a property value (ref) by name
	bool SetPropertyRef(LPCTSTR strPropertyName, ...);
	// set a property value (ref) by index
	bool SetPropertyRef(int nPropertyIndex, ...);
	// get return type of a method by name
	VARTYPE GetReturnType(LPCTSTR strMethodName);
	// get return type of a method by index
	VARTYPE GetReturnType(int nMethodIndex);
	// get number of parameters in a method by name
	int GetParamCount(LPCTSTR strMethodName);
	// get number of parameters in a method by index
	int GetParamCount(int nMethodIndex);
	// get the type of a parameter in a method by name
	VARTYPE GetParamType(LPCTSTR strMethodName, const int nParamIndex);
	// get the type of a parameter in a method by index
	VARTYPE GetParamType(int nMethodIndex, const int nParamIndex);
	// invoke a method by name
	VARIANT* InvokeMethod(LPCTSTR strMethodName, ...);
	// invoke a method by index
	VARIANT* InvokeMethod(int nMethodIndex, ...);
	// get the last error code as HRESULT
	HRESULT GetLastError() { return m_hRet; }
	// get exception info
	EXCEPINFO* GetExceptionInfo() { return m_pExceptInfo; }
};

#endif
