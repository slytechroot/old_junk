// RemoteShellGUIClient.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "RemoteShellGUIClient.h"
#include "ClientDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRemoteShellGUIClientApp

BEGIN_MESSAGE_MAP(CRemoteShellGUIClientApp, CWinApp)
	//{{AFX_MSG_MAP(CRemoteShellGUIClientApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRemoteShellGUIClientApp construction

CRemoteShellGUIClientApp::CRemoteShellGUIClientApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CRemoteShellGUIClientApp object

CRemoteShellGUIClientApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CRemoteShellGUIClientApp initialization

BOOL CRemoteShellGUIClientApp::InitInstance()
{
	// Standard initialization

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	static CClientDlg dlg;
	m_pMainWnd = &dlg;
	if (dlg.Create(IDD_REMOTESHELLGUICLIENT_DIALOG))
	{
		return TRUE;
	}
	return FALSE;
}
