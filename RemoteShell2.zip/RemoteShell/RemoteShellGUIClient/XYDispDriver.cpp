
#include "XYDispDriver.h"

void CharToWChar(unsigned short* pTarget, const char* pSource)
{
	while(*pSource)
	{
		*pTarget = *pSource;
		pSource++;
		pTarget++;
	}
	*pTarget = 0;
}

XYDispInfo::XYDispInfo()
{
	m_dispID = 0;
	m_bstrName = NULL;
	m_wFlag = DISPATCH_METHOD;
	m_vtOutputType = VT_NULL;
	m_pOutput = NULL;
	m_nParamCount = 0;
	m_pParamTypes = NULL;
}

XYDispInfo::~XYDispInfo()
{
	if(m_bstrName!=NULL)
	{
		::SysFreeString(m_bstrName);
	}
	if(m_pOutput!=NULL&&m_vtOutputType==VT_BSTR&&m_pOutput->bstrVal!=NULL)
	{
		::SysFreeString(m_pOutput->bstrVal);
	}
	delete m_pOutput;
	delete []m_pParamTypes;
}

XYDispDriver::XYDispDriver()
{
	static bool bInit = true;
	if(bInit)
	{
		bInit = false;
		CoInitialize(NULL);
	}
	m_pDisp = NULL;
	m_nDispInfoCount = 0;
	m_pDispInfo = NULL;
	m_hRet = S_OK;
	m_pExceptInfo = NULL;
}

XYDispDriver::~XYDispDriver()
{
	Clear();
}

void XYDispDriver::Clear()
{
	m_hRet = S_OK;
	if(m_pExceptInfo!=NULL)
	{
		::SysFreeString(m_pExceptInfo->bstrSource);
		::SysFreeString(m_pExceptInfo->bstrDescription);
		::SysFreeString(m_pExceptInfo->bstrHelpFile);
		delete m_pExceptInfo;
		m_pExceptInfo = NULL;
	}
	if(m_pDisp!=NULL)
	{
		m_pDisp->Release();
		m_pDisp = NULL;
	}
	if(m_pDispInfo)
	{
		delete []m_pDispInfo;
		m_pDispInfo = NULL;
	}
	m_nDispInfoCount = 0;
}
	
bool XYDispDriver::CreateObject(LPCTSTR strProgID, DWORD dwClsContext)
{
	Clear();
	CLSID clsid;
	#ifdef _UNICODE
	WCHAR* pProgID = strProgID;
	#else
	WCHAR pProgID[XYDISPDRIVER_OLENAMELEN+1];
	CharToWChar(pProgID,strProgID);
	#endif
	m_hRet = ::CLSIDFromProgID(pProgID, &clsid);
	if(m_hRet==S_OK) return CreateObject(clsid, dwClsContext);
	else
	{
		#ifdef XYDISPDRIVER_DEBUG
		_tprintf(_T("CLSIDFromProgID failed\n"));
		#endif
		return false;
	}
}

bool XYDispDriver::CreateObject(CLSID clsid, DWORD dwClsContext)
{
	Clear();
	m_hRet = ::CoCreateInstance(clsid,NULL,dwClsContext,IID_IDispatch,(void**)(&m_pDisp));
	if(m_hRet!=S_OK) 
	{
		#ifdef XYDISPDRIVER_DEBUG
		_tprintf(_T("CoCreateInstance failed\n"));
		#endif
		return false;
	}

	ITypeInfo* pTypeInfo;
	m_hRet = m_pDisp->GetTypeInfo(0,LOCALE_SYSTEM_DEFAULT,&pTypeInfo);
	if(m_hRet!=S_OK) 
	{
		#ifdef XYDISPDRIVER_DEBUG
		_tprintf(_T("GetTypeInfo failed\n"));
		#endif
		return false;
	}

	TYPEATTR* pTypeAttr;
	m_hRet = pTypeInfo->GetTypeAttr(&pTypeAttr);
	if(m_hRet!=S_OK) 
	{
		pTypeInfo->Release();
		#ifdef XYDISPDRIVER_DEBUG
		_tprintf(_T("GetTypeAttr failed\n"));
		#endif
		return false;
	}

	m_nDispInfoCount = pTypeAttr->cFuncs;
	#ifdef XYDISPDRIVER_DEBUG
	_tprintf(_T("Method and property count = %d\n"), m_nDispInfoCount);
	#endif
	m_pDispInfo = new XYDispInfo[m_nDispInfoCount];

	for(int i=0;i<m_nDispInfoCount;i++)
	{
		FUNCDESC* pFuncDesc;
		m_hRet = pTypeInfo->GetFuncDesc(i, &pFuncDesc); 
		if(m_hRet!=S_OK) 
		{
			#ifdef XYDISPDRIVER_DEBUG
			_tprintf(_T("GetFuncDesc failed\n"));
			#endif
			pTypeInfo->ReleaseTypeAttr(pTypeAttr);
			pTypeInfo->Release();
			m_nDispInfoCount = 0;
			return false; 
		}
		m_pDispInfo[i].m_dispID = pFuncDesc->memid;
		#ifdef XYDISPDRIVER_DEBUG
		_tprintf(_T("%d: DispID = %d\n"),i, m_pDispInfo[i].m_dispID);
		#endif

		unsigned int nCount;
		m_hRet = pTypeInfo->GetNames(m_pDispInfo[i].m_dispID ,&m_pDispInfo[i].m_bstrName,1,&nCount); 
		if(m_hRet!=S_OK)
		{
			#ifdef XYDISPDRIVER_DEBUG
			_tprintf(_T("GetNames failed\n"));
			#endif
			pTypeInfo->ReleaseFuncDesc(pFuncDesc);
			pTypeInfo->ReleaseTypeAttr(pTypeAttr);
			pTypeInfo->Release();
			m_nDispInfoCount = 0;
			return false; 
		}
		#ifdef XYDISPDRIVER_DEBUG
		wprintf(L"MethodName = %s\n", m_pDispInfo[i].m_bstrName);
		#endif
		
		switch(pFuncDesc->invkind)
		{
		case INVOKE_PROPERTYGET:
			m_pDispInfo[i].m_wFlag = DISPATCH_PROPERTYGET;
			#ifdef XYDISPDRIVER_DEBUG
			_tprintf(_T("PropertyGet\n"));
			#endif
			break;
		case INVOKE_PROPERTYPUT:
			m_pDispInfo[i].m_wFlag = DISPATCH_PROPERTYPUT;
			#ifdef XYDISPDRIVER_DEBUG
			_tprintf(_T("PropertyPut\n"));
			#endif
			break;
		case INVOKE_PROPERTYPUTREF:
			m_pDispInfo[i].m_wFlag = DISPATCH_PROPERTYPUTREF;
			#ifdef XYDISPDRIVER_DEBUG
			_tprintf(_T("PropertyPutRef\n"));
			#endif
			break;
		case INVOKE_FUNC:
			#ifdef XYDISPDRIVER_DEBUG
			_tprintf(_T("DispatchMethod\n"));
			#endif
		default:
			m_pDispInfo[i].m_wFlag = DISPATCH_METHOD;
			break;
		}
		
		m_pDispInfo[i].m_pOutput = new VARIANT;
		::VariantInit(m_pDispInfo[i].m_pOutput);
		m_pDispInfo[i].m_vtOutputType = pFuncDesc->elemdescFunc.tdesc.vt;
		#ifdef XYDISPDRIVER_DEBUG
		_tprintf(_T("Return type = %d\n"), m_pDispInfo[i].m_vtOutputType);
		#endif
		if(m_pDispInfo[i].m_vtOutputType==VT_VOID||m_pDispInfo[i].m_vtOutputType==VT_NULL)
		{
			m_pDispInfo[i].m_vtOutputType = VT_EMPTY;
		}
		
		m_pDispInfo[i].m_nParamCount = pFuncDesc->cParams;
		#ifdef XYDISPDRIVER_DEBUG
		_tprintf(_T("ParamCount = %d\n"), m_pDispInfo[i].m_nParamCount);
		#endif
		
		m_pDispInfo[i].m_pParamTypes = new BYTE[m_pDispInfo[i].m_nParamCount+1];
		for(int j=0;j<m_pDispInfo[i].m_nParamCount;j++)
		{
			m_pDispInfo[i].m_pParamTypes[j] = (BYTE)(pFuncDesc->lprgelemdescParam[j].tdesc.vt);
			#ifndef _UNICODE
			if(m_pDispInfo[i].m_pParamTypes[j]==VT_BSTR)
			{
				m_pDispInfo[i].m_pParamTypes[j] = 14;
			}
			#endif
			#ifdef XYDISPDRIVER_DEBUG
			_tprintf(_T("Param(%d) type = %d\n"),j,m_pDispInfo[i].m_pParamTypes[j]);
			#endif
		}
		m_pDispInfo[i].m_pParamTypes[m_pDispInfo[i].m_nParamCount] = 0;
		pTypeInfo->ReleaseFuncDesc(pFuncDesc);
	}

	pTypeInfo->ReleaseTypeAttr(pTypeAttr);	
	pTypeInfo->Release();
	return true;
}

int XYDispDriver::FindProperty(LPCTSTR strPropertyName, const WORD wFlag) 
{ 
	return FindDispInfo(strPropertyName,wFlag); 
}
	
int XYDispDriver::FindMethod(LPCTSTR strMethodName) 
{ 
	return FindDispInfo(strMethodName); 
}

VARTYPE XYDispDriver::GetPropertyType(LPCTSTR strPropertyName)
{
	int nPropertyIndex = FindProperty(strPropertyName);
	if(nPropertyIndex>=0) 
	{
		return m_pDispInfo[nPropertyIndex].m_vtOutputType;
	}
	return VT_EMPTY;
}
	
VARTYPE XYDispDriver::GetPropertyType(int nPropertyIndex)
{
	if(m_pDispInfo[nPropertyIndex].m_wFlag==DISPATCH_PROPERTYGET)
	{
		return m_pDispInfo[nPropertyIndex].m_vtOutputType;
	}
	return VT_EMPTY;
}
	
VARIANT* XYDispDriver::GetProperty(LPCTSTR strPropertyName)
{
	int nPropertyIndex = FindProperty(strPropertyName);
	if(nPropertyIndex>=0) 
	{
		va_list argList;
		va_start(argList,strPropertyName);
		m_hRet = InvokeMethodV(nPropertyIndex, argList);
		va_end(argList);
		return m_hRet==S_OK?m_pDispInfo[nPropertyIndex].m_pOutput:NULL;
	}
	return NULL;
}
	
VARIANT* XYDispDriver::GetProperty(int nPropertyIndex)
{
	if(m_pDispInfo[nPropertyIndex].m_wFlag==DISPATCH_PROPERTYGET)
	{
		va_list argList;
		va_start(argList,nPropertyIndex);
		m_hRet = InvokeMethodV(nPropertyIndex, argList);
		va_end(argList);
		return m_hRet==S_OK?m_pDispInfo[nPropertyIndex].m_pOutput:NULL;
	}
	return NULL;
}
	
bool XYDispDriver::SetProperty(LPCTSTR strPropertyName, ...)
{
	int nPropertyIndex = FindProperty(strPropertyName,DISPATCH_PROPERTYPUT);
	if(nPropertyIndex>=0) 
	{
		va_list argList;
		va_start(argList,strPropertyName);
		m_hRet = InvokeMethodV(nPropertyIndex, argList);
		va_end(argList);
		return m_hRet==S_OK;
	}
	return false;
}
	
bool XYDispDriver::SetProperty(int nPropertyIndex, ...)
{
	if(m_pDispInfo[nPropertyIndex].m_wFlag==DISPATCH_PROPERTYPUT) 
	{
		va_list argList;
		va_start(argList,nPropertyIndex);
		m_hRet = InvokeMethodV(nPropertyIndex, argList);
		va_end(argList);
		return m_hRet==S_OK;
	}
	return false;	
}
	
bool XYDispDriver::SetPropertyRef(LPCTSTR strPropertyName, ...)
{
	int nPropertyIndex = FindProperty(strPropertyName,DISPATCH_PROPERTYPUTREF);
	if(nPropertyIndex>=0) 
	{
		va_list argList;
		va_start(argList,strPropertyName);
		m_hRet = InvokeMethodV(nPropertyIndex, argList);
		va_end(argList);
		return m_hRet==S_OK;
	}
	return false;
}
	
bool XYDispDriver::SetPropertyRef(int nPropertyIndex, ...)
{
	if(m_pDispInfo[nPropertyIndex].m_wFlag==DISPATCH_PROPERTYPUTREF) 
	{
		va_list argList;
		va_start(argList,nPropertyIndex);
		m_hRet = InvokeMethodV(nPropertyIndex, argList);
		va_end(argList);
		return m_hRet==S_OK;
	}
	return false;	
}
	
VARTYPE XYDispDriver::GetReturnType(LPCTSTR strMethodName)
{
	int nMethodIndex = FindMethod(strMethodName);
	if(nMethodIndex>=0) 
	{
		return m_pDispInfo[nMethodIndex].m_vtOutputType;
	}
	return VT_EMPTY;
}
	
VARTYPE XYDispDriver::GetReturnType(int nMethodIndex)
{
	if(m_pDispInfo[nMethodIndex].m_wFlag==DISPATCH_METHOD)
	{
		return m_pDispInfo[nMethodIndex].m_vtOutputType;
	}
	return VT_EMPTY;
}
	
int XYDispDriver::GetParamCount(LPCTSTR strMethodName)
{
	int nMethodIndex = FindMethod(strMethodName);
	if(nMethodIndex>=0)
	{
		return m_pDispInfo[nMethodIndex].m_nParamCount;
	}
	return -1;
}
	
int XYDispDriver::GetParamCount(int nMethodIndex)
{
	if(m_pDispInfo[nMethodIndex].m_wFlag==DISPATCH_METHOD)
	{
		return m_pDispInfo[nMethodIndex].m_nParamCount;
	}
	return -1;
}
	
VARTYPE XYDispDriver::GetParamType(LPCTSTR strMethodName, const int nParamIndex)
{
	int nMethodIndex = FindMethod(strMethodName);
	if(nMethodIndex>=0)
	{
		if(nParamIndex>=0&&nParamIndex<m_pDispInfo[nMethodIndex].m_nParamCount)
		{
			return (VARTYPE)(m_pDispInfo[nMethodIndex].m_pParamTypes[nParamIndex]);
		}
	}
	return VT_EMPTY;
}
	
VARTYPE XYDispDriver::GetParamType(int nMethodIndex, const int nParamIndex)
{
	if(m_pDispInfo[nMethodIndex].m_wFlag==DISPATCH_METHOD)
	{
		if(nParamIndex>=0&&nParamIndex<m_pDispInfo[nMethodIndex].m_nParamCount)
		{
			return (VARTYPE)(m_pDispInfo[nMethodIndex].m_pParamTypes[nParamIndex]);
		}
	}
	return VT_EMPTY;
}
	
VARIANT* XYDispDriver::InvokeMethod(LPCTSTR strMethodName, ...)
{
	int nMethodIndex = FindMethod(strMethodName);
	if(nMethodIndex>=0)
	{
		va_list argList;
		va_start(argList,strMethodName);
		m_hRet = InvokeMethodV(nMethodIndex, argList);
		va_end(argList);
		return m_hRet==S_OK?m_pDispInfo[nMethodIndex].m_pOutput:NULL;
	}
	return NULL;
}
	
VARIANT* XYDispDriver::InvokeMethod(int nMethodIndex, ...)
{
	if(m_pDispInfo[nMethodIndex].m_wFlag==DISPATCH_METHOD)
	{
		va_list argList;
		va_start(argList,nMethodIndex);
		m_hRet = InvokeMethodV(nMethodIndex, argList);
		va_end(argList);
		return m_hRet==S_OK?m_pDispInfo[nMethodIndex].m_pOutput:NULL;
	}
	return NULL;
}

int XYDispDriver::FindDispInfo(LPCTSTR strName, const WORD wFlag)
{
	#ifdef _UNICODE
	WCHAR* pName = strName;
	#else
	WCHAR pName[XYDISPDRIVER_OLENAMELEN+1];
	CharToWChar(pName,strName);
	#endif
	int nRet = -1;
	for(int i=0;i<m_nDispInfoCount;i++)
	{
		if(wcscmp(pName,m_pDispInfo[i].m_bstrName)==0&&m_pDispInfo[i].m_wFlag==wFlag)
		{
			nRet = i;
			break;
		}
	}
	return nRet;
}

HRESULT XYDispDriver::InvokeMethodV(int nIndex, va_list argList)
{
	m_hRet = S_OK;

	DISPPARAMS dispparams;
	memset(&dispparams, 0, sizeof dispparams);
	dispparams.cArgs = m_pDispInfo[nIndex].m_nParamCount;

	DISPID dispidNamed = DISPID_PROPERTYPUT;
	if(m_pDispInfo[nIndex].m_wFlag&(DISPATCH_PROPERTYPUT|DISPATCH_PROPERTYPUTREF))
	{
		dispparams.cNamedArgs = 1;
		dispparams.rgdispidNamedArgs = &dispidNamed;
	}

	if(dispparams.cArgs!=0)
	{
		// allocate memory for all VARIANT parameters
		VARIANT* pArg = new VARIANT[dispparams.cArgs];
		dispparams.rgvarg = pArg;
		memset(pArg, 0, sizeof(VARIANT) * dispparams.cArgs);

		// get ready to walk vararg list
		const BYTE* pb = m_pDispInfo[nIndex].m_pParamTypes;
		pArg += dispparams.cArgs - 1;   // params go in opposite order

		while(*pb!=0)
		{
			pArg->vt = *pb; // set the variant type
			switch (pArg->vt)
			{
			case VT_UI1:
				pArg->bVal = va_arg(argList, BYTE);
				break;
			case VT_I2:
				pArg->iVal = va_arg(argList, short);
				break;
			case VT_I4:
				pArg->lVal = va_arg(argList, long);
				break;
			case VT_R4:
				pArg->vt = VT_R8;
				*(double*)&pArg->dblVal = va_arg(argList, double);
				break;
			case VT_R8:
				*(double*)&pArg->dblVal = va_arg(argList, double);
				break;
			case VT_DATE:
				*(double*)&pArg->date = va_arg(argList, double);
				break;
			case VT_CY:
				pArg->cyVal = *va_arg(argList, CY*);
				break;
			case VT_BSTR:
				{
					LPCOLESTR lpsz = va_arg(argList, LPOLESTR);
					pArg->bstrVal = ::SysAllocString(lpsz);
				}
				break;
			#ifndef _UNICODE
			case 14:
				{
					LPCSTR lpsz = va_arg(argList, LPSTR);
					WCHAR* pData = new WCHAR[strlen(lpsz)+1];
					CharToWChar(pData,lpsz);
					pArg->bstrVal = ::SysAllocString(pData);
					delete []pData;
					pArg->vt = VT_BSTR;
				}
				break;
			#endif
			case VT_DISPATCH:
				pArg->pdispVal = va_arg(argList, LPDISPATCH);
				break;
			case VT_ERROR:
				pArg->scode = va_arg(argList, SCODE);
				break;
			case VT_BOOL:
				V_BOOL(pArg) = (VARIANT_BOOL)(va_arg(argList, BOOL) ? -1 : 0);
				break;
			case VT_VARIANT:
				*pArg = *va_arg(argList, VARIANT*);
				break;
			case VT_UNKNOWN:
				pArg->punkVal = va_arg(argList, LPUNKNOWN);
				break;
			case VT_I2|VT_BYREF:
				pArg->piVal = va_arg(argList, short*);
				break;
			case VT_UI1|VT_BYREF:
				pArg->pbVal = va_arg(argList, BYTE*);
				break;
			case VT_I4|VT_BYREF:
				pArg->plVal = va_arg(argList, long*);
				break;
			case VT_R4|VT_BYREF:
				pArg->pfltVal = va_arg(argList, float*);
				break;
			case VT_R8|VT_BYREF:
				pArg->pdblVal = va_arg(argList, double*);
				break;
			case VT_DATE|VT_BYREF:
				pArg->pdate = va_arg(argList, DATE*);
				break;
			case VT_CY|VT_BYREF:
				pArg->pcyVal = va_arg(argList, CY*);
				break;
			case VT_BSTR|VT_BYREF:
				pArg->pbstrVal = va_arg(argList, BSTR*);
				break;
			case VT_DISPATCH|VT_BYREF:
				pArg->ppdispVal = va_arg(argList, LPDISPATCH*);
				break;
			case VT_ERROR|VT_BYREF:
				pArg->pscode = va_arg(argList, SCODE*);
				break;
			case VT_BOOL|VT_BYREF:
				{
					// coerce BOOL into VARIANT_BOOL
					BOOL* pboolVal = va_arg(argList, BOOL*);
					*pboolVal = *pboolVal ? MAKELONG(0, -1) : 0;
					pArg->pboolVal = (VARIANT_BOOL*)pboolVal;
				}
				break;
			case VT_VARIANT|VT_BYREF:
				pArg->pvarVal = va_arg(argList, VARIANT*);
				break;
			case VT_UNKNOWN|VT_BYREF:
				pArg->ppunkVal = va_arg(argList, LPUNKNOWN*);
				break;
			default:
				break;
			}
			--pArg; // get ready to fill next argument
			++pb;
		}
	}

	// initialize return value
	VARIANT* pvarResult = NULL;
	if (m_pDispInfo[nIndex].m_vtOutputType!=VT_EMPTY)
	{
		pvarResult = m_pDispInfo[nIndex].m_pOutput;
		::VariantInit(pvarResult);
	}

	// initialize EXCEPINFO struct
	if(m_pExceptInfo!=NULL)
	{
		::SysFreeString(m_pExceptInfo->bstrSource);
		::SysFreeString(m_pExceptInfo->bstrDescription);
		::SysFreeString(m_pExceptInfo->bstrHelpFile);
		delete m_pExceptInfo;
	}
	m_pExceptInfo = new EXCEPINFO;
	memset(m_pExceptInfo, 0, sizeof(*m_pExceptInfo));

	UINT nArgErr = (UINT)-1;  // initialize to invalid arg

	// make the call
	m_hRet = m_pDisp->Invoke(m_pDispInfo[nIndex].m_dispID,IID_NULL,LOCALE_SYSTEM_DEFAULT,m_pDispInfo[nIndex].m_wFlag,&dispparams,pvarResult,m_pExceptInfo,&nArgErr);

	// cleanup any arguments that need cleanup
	if (dispparams.cArgs != 0)
	{
		VARIANT* pArg = dispparams.rgvarg + dispparams.cArgs - 1;
		const BYTE* pb = m_pDispInfo[nIndex].m_pParamTypes;
		while (*pb != 0)
		{
			switch ((VARTYPE)*pb)
			{
			#ifndef _UNICODE
			case 14:
			#endif
			case VT_BSTR:
				::SysFreeString(pArg->bstrVal);
				break;
			}
			--pArg;
			++pb;
		}
	}
	delete[] dispparams.rgvarg;

	// throw exception on failure
	if(m_hRet<0)
	{
		::VariantClear(m_pDispInfo[nIndex].m_pOutput);
		if(m_hRet!=DISP_E_EXCEPTION) 
		{
			#ifdef XYDISPDRIVER_DEBUG
			_tprintf(_T("Invoke failed: no exception\n"));
			#endif
			delete m_pExceptInfo;
			return m_hRet;
		}

		// make sure excepInfo is filled in
		if(m_pExceptInfo->pfnDeferredFillIn != NULL)
			m_pExceptInfo->pfnDeferredFillIn(m_pExceptInfo);

		#ifdef XYDISPDRIVER_DEBUG
		wprintf(L"Exception source: %s\n",m_pExceptInfo->bstrSource);
		wprintf(L"Exception description: %s\n",m_pExceptInfo->bstrDescription);
		wprintf(L"Exception help file: %s\n",m_pExceptInfo->bstrHelpFile);
		#endif
		return m_hRet;
	}

	if(m_pDispInfo[nIndex].m_vtOutputType!=VT_EMPTY)
	{
		m_pDispInfo[nIndex].m_pOutput->vt = m_pDispInfo[nIndex].m_vtOutputType;
	}

	delete m_pExceptInfo;
	m_pExceptInfo = NULL;
	return m_hRet;
}
	
