// ClientDlg.cpp : implementation file
//

#include "stdafx.h"
#include "RemoteShellGUIClient.h"
#include "ClientDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CClientDlg dialog

// private helper function to turn a single \n (new line) into \r\n
CString FixNewLine(const CString& strInput)
{
	int nSize = strInput.GetLength();
	CString strOutput;
	TCHAR* pOutput = strOutput.GetBuffer(2*nSize);
	int nPos = 0;
	for(int i=0;i<nSize;i++)
	{
		if(strInput[i]==10&&(i>0&&strInput[i]!=13||i<(nSize-1)&&strInput[i]!=13))
		{
			pOutput[nPos++] = 13;
			pOutput[nPos++] = 10;
		}
		else pOutput[nPos++] = strInput[i];
	}
	strOutput.ReleaseBuffer(nPos);
	return strOutput;
}

CClientDlg::CClientDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CClientDlg::IDD, pParent)
{
	m_nSearch = -1;
	//{{AFX_DATA_INIT(CClientDlg)
	m_strServer = _T("myserver.ipaddress.com");
	m_nPort = 3200;
	m_strCommand = _T("mycommand  arg1  arg2  arg3  arg4");
	m_strInput = _T("myinputdata\r\nline1\r\nline2\r\n...");
	m_strOutput = _T("");
	m_bOutput = TRUE;
	m_strSearch = _T("");
	//}}AFX_DATA_INIT
}

void CClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CClientDlg)
	DDX_Control(pDX, IDC_EDIT_OUTPUT, m_editOutput);
	DDX_Text(pDX, IDC_EDIT_SERVER, m_strServer);
	DDX_Text(pDX, IDC_EDIT_PORT, m_nPort);
	DDV_MinMaxInt(pDX, m_nPort, 1, 65535);
	DDX_Text(pDX, IDC_EDIT_COMMAND, m_strCommand);
	DDX_Text(pDX, IDC_EDIT_INPUT, m_strInput);
	DDX_Text(pDX, IDC_EDIT_OUTPUT, m_strOutput);
	DDX_Check(pDX, IDC_CHECK_OUTPUT, m_bOutput);
	DDX_Text(pDX, IDC_EDIT_SEARCH, m_strSearch);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CClientDlg, CDialog)
	//{{AFX_MSG_MAP(CClientDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_BUTTON_CLEAR, OnButtonClear)
	ON_BN_CLICKED(IDC_BUTTON_CONNECT, OnButtonConnect)
	ON_BN_CLICKED(IDC_BUTTON_RUN, OnButtonRun)
	ON_EN_CHANGE(IDC_EDIT_COMMAND, OnChangeEditCommand)
	ON_BN_CLICKED(IDC_CHECK_OUTPUT, OnCheckOutput)
	ON_BN_CLICKED(IDC_BUTTON_SEARCH, OnButtonSearch)
	ON_EN_CHANGE(IDC_EDIT_SEARCH, OnChangeEditSearch)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClientDlg message handlers

BOOL CClientDlg::OnInitDialog()
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	CDialog::OnInitDialog();
	
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	// create the "RemoteShellClient" com object
	CString strProgID = _T("RemoteShellClient.1");
	if(m_driver.CreateObject(strProgID)==false)
	{
		AfxMessageBox(_T("Failed to create com object: ")+strProgID);
		PostQuitMessage(0);
	}
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CClientDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CClientDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CClientDlg::OnClose() 
{
	// clean up
	m_driver.InvokeMethod(_T("Disconnect"));
	DestroyWindow();
	PostQuitMessage(0);
}

void CClientDlg::OnButtonClear() 
{
	// clear command, input, and output fields
	m_strCommand = _T("");
	m_strInput = _T("");
	m_strOutput = _T("");
	UpdateData(FALSE);
}

void CClientDlg::OnButtonConnect() 
{
	// connect to the remote server using the RemoteShellClient object
	UpdateData(TRUE);
	m_driver.InvokeMethod(_T("Disconnect"));
	VARIANT* pOutput = m_driver.InvokeMethod(_T("Connect"),m_strServer,m_nPort);
	if(pOutput&&pOutput->boolVal)
	{
		// clear output field when successful
		m_strOutput = _T("Connected to server");
	}
	else
	{
		// set error display
		m_strOutput = _T("Failed to connect to remote server");
	}
	UpdateData(FALSE);
}

void CClientDlg::OnButtonRun() 
{
	// execute the command with its input on the remote server
	UpdateData(TRUE);
	VARIANT* pOutput = m_driver.InvokeMethod(_T("Execute"),m_strCommand,m_strInput);
	if(pOutput&&pOutput->boolVal)
	{
		// clear output field
		m_strOutput = _T("");
		if(m_bOutput) 
		{
			// get output from remote server
			CWaitCursor wc;
			while(true)
			{
				VARIANT* pOutput = m_driver.InvokeMethod(_T("GetOutput"));
				if(pOutput)
				{
					CString strOutput = CString(pOutput->bstrVal);
					if(strOutput.IsEmpty())
					{
						// if no more output, get out of loop
						break;
					}
					else
					{
						// if there is more output, continue
						m_strOutput += FixNewLine(strOutput);
					}
				}
				else
				{
					// set error display
					m_strOutput = _T("Failed to get output from server");
					break;
				}
			}
		}
		
	}
	else
	{
		// set error display
		m_strOutput = _T("Failed to execute command");
	}
	UpdateData(FALSE);
}

void CClientDlg::OnChangeEditCommand() 
{
	// clear the input field when the command field changes
	GetDlgItem(IDC_EDIT_INPUT)->SetWindowText(_T(""));
}

void CClientDlg::OnCheckOutput() 
{
	// reconnect
	OnButtonConnect();
}

void CClientDlg::OnButtonSearch() 
{
	UpdateData();
	if(m_strSearch.IsEmpty())
	{
		AfxMessageBox(_T("Please specify text string to search in the output field"));
		GetDlgItem(IDC_EDIT_SEARCH)->SetFocus();
		return;
	}
	CString strData = m_nSearch<0?m_strOutput:m_strOutput.Mid(m_nSearch+1);
	int nSearch = strData.Find(m_strSearch);
	if(nSearch<0)
	{
		m_nSearch = -1;
		AfxMessageBox(_T("Specified text not found in output: ")+m_strSearch);
	}
	else
	{
		m_nSearch = m_nSearch<0?nSearch:(m_nSearch+nSearch+1);
		m_editOutput.SetSel(m_nSearch,m_nSearch+m_strSearch.GetLength());
	}
}

void CClientDlg::OnChangeEditSearch() 
{
	m_nSearch = -1;
}
