// RemoteShellGUIClient.h : main header file for the REMOTESHELLGUICLIENT application
//

#if !defined(AFX_REMOTESHELLGUICLIENT_H__3F70D58A_C308_11D5_880E_00B0D055B523__INCLUDED_)
#define AFX_REMOTESHELLGUICLIENT_H__3F70D58A_C308_11D5_880E_00B0D055B523__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CRemoteShellGUIClientApp:
// See RemoteShellGUIClient.cpp for the implementation of this class
//

class CRemoteShellGUIClientApp : public CWinApp
{
public:
	CRemoteShellGUIClientApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRemoteShellGUIClientApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CRemoteShellGUIClientApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REMOTESHELLGUICLIENT_H__3F70D58A_C308_11D5_880E_00B0D055B523__INCLUDED_)
