// RemoteClient.cpp : Implementation of CRemoteClient
#include "stdafx.h"
#include "RemoteShellClient.h"
#include "RemoteClient.h"


// uncomment the following line to allow debug message boxes
// #define REMOTESHELLCLIENT_DEBUG


/////////////////////////////////////////////////////////////////////////////
// CRemoteClient

// private helper function to turn wchar string to char string
void WCharToChar(char* pTarget, const unsigned short* pSource)
{
	while(*pSource)
	{
		*pTarget = (char)(*pSource);
		pSource++;
		pTarget++;
	}
	*pTarget = 0;
}

// private helper function to turn char string to wchar string
void CharToWChar(unsigned short* pTarget, const char* pSource)
{
	while(*pSource)
	{
		*pTarget = *pSource;
		pSource++;
		pTarget++;
	}
	*pTarget = 0;
}

// connect to the server
STDMETHODIMP CRemoteClient::Connect(BSTR strServerAddress, long nServerPort, BOOL * pOutput)
{
	// first, initialize win sock (this is done only once)
	static bool bInit = true;
	if(bInit)
	{
		bInit = false;
		WORD wVersionRequested = MAKEWORD(2, 0);
		WSADATA wsaData;
		if(::WSAStartup(wVersionRequested,&wsaData)!=0)
		{
			// WSAStartup failed
#ifdef REMOTESHELLCLIENT_DEBUG
			::MessageBox(NULL,"Failed to call WSAStartup","RemoteShellClient",MB_OK);
#endif
			bInit = true;
			*pOutput = FALSE;
			return S_OK;
		}
		if(LOBYTE(wsaData.wVersion)!=2||HIBYTE(wsaData.wVersion)!=0)
		{
			// incorrect win sock version
#ifdef REMOTESHELLCLIENT_DEBUG
			::MessageBox(NULL,"Invalid winsock version","RemoteShellClient",MB_OK);
#endif
			bInit = true;
			*pOutput = FALSE;
			return S_OK;
		}
	}
	// disconnect previous connection
	Disconnect();
	// create socket
	m_socket = ::socket(AF_INET,SOCK_STREAM,0);
	if(m_socket==INVALID_SOCKET)
	{
		// failed to create socket
#ifdef REMOTESHELLCLIENT_DEBUG
		::MessageBox(NULL,"Failed to create socket","RemoteShellClient",MB_OK);
#endif
		*pOutput = FALSE;
		return S_OK;
	}
	else
	{
		// resolve server ip address
		int nLen = wcslen(strServerAddress);
		char* pServerAddress;
		if(nLen>0) 
		{
			// use char string instead of wchar string
			pServerAddress = new char[nLen+1];
			WCharToChar(pServerAddress,strServerAddress);
		}
		else
		{
			// use computer name if server address is empty
			nLen = MAX_COMPUTERNAME_LENGTH+1;
			pServerAddress = new char[nLen];
			::GetComputerName(pServerAddress,(DWORD*)&nLen);
		}
		SOCKADDR_IN sockAddr;
		memset(&sockAddr,0,sizeof(sockAddr));
		sockAddr.sin_family = AF_INET;
		// get ip address
		DWORD lResult = inet_addr(pServerAddress);
		if(lResult==INADDR_NONE)
		{
			// if inet_addr failed, get host by name
			LPHOSTENT lphost;
			lphost = gethostbyname(pServerAddress);
			if(lphost!=NULL)
			{
				sockAddr.sin_addr.s_addr = ((LPIN_ADDR)lphost->h_addr)->s_addr;
			}
			else
			{
				// failed to resolve ip address
#ifdef REMOTESHELLCLIENT_DEBUG
				::MessageBox(NULL,"Failed to get host name","RemoteShellClient",MB_OK);
#endif
				delete []pServerAddress;
				*pOutput = FALSE;
				return S_OK;
			}		
		}
		else
		{
			sockAddr.sin_addr.s_addr = lResult;
		}
		delete []pServerAddress;
		// set server port
		sockAddr.sin_port = htons((u_short)nServerPort);
		// connect to server
		if(::connect(m_socket,(SOCKADDR*)&sockAddr,sizeof(sockAddr))==SOCKET_ERROR)
		{
			// failed to connect to server
#ifdef REMOTESHELLCLIENT_DEBUG
			::MessageBox(NULL,"Failed to connect to server","RemoteShellClient",MB_OK);
#endif
			*pOutput = FALSE;
			return S_OK;
		}
	}
	// successfully connected
	*pOutput = TRUE;
	return S_OK;
}

// execute a command string on the remote server with given input string
STDMETHODIMP CRemoteClient::Execute(BSTR strCommandLine, BSTR strInputData, BOOL * pOutput)
{
	// turn command string from wchar to char
	int nCommandSize = wcslen(strCommandLine);	
	char* pCommand = new char[nCommandSize+1];
	WCharToChar(pCommand,strCommandLine);
	// turn input string from wchar to char
	int nInputSize = wcslen(strInputData);
	char* pInput = new char[nInputSize+1];
	WCharToChar(pInput,strInputData);
	// execute the command on the remote server with given input data
	ExecuteEx((long)pCommand,nCommandSize,(long)pInput,nInputSize,pOutput);
	delete []pCommand;
	delete []pInput;
	return S_OK;
}

// disconnect the socket connection to the remote server
STDMETHODIMP CRemoteClient::Disconnect()
{
	if(m_socket!=INVALID_SOCKET)
	{
		BOOL bOutput;
		ExecuteEx(0,0,0,0,&bOutput);
		if(::closesocket(m_socket)==SOCKET_ERROR)
		{
#ifdef REMOTESHELLCLIENT_DEBUG
			::MessageBox(NULL,"Failed to close socket","RemoteShellClient",MB_OK);
#endif
		}
		m_socket = INVALID_SOCKET;
	}
	return S_OK;
}

// execute a command on the remote server with given input data
// the pCommand and pInput arguments are pointers to data blocks
// the nCommandSize and nInputSize arguments are data length in bytes
STDMETHODIMP CRemoteClient::ExecuteEx(long pCommand, long nCommandSize, long pInput, long nInputSize, BOOL * pOutput)
{
	// first, send the command length to the remote server
	// in a platform-independent way
	char pCommandLen[4] =
	{
		(byte)(0x000000ff&nCommandSize),
		(byte)(0x000000ff&(nCommandSize>>8)),
		(byte)(0x000000ff&(nCommandSize>>16)),
		(byte)(0x000000ff&(nCommandSize>>24))
	};
	if(::send(m_socket,pCommandLen,4,0)==SOCKET_ERROR)
	{
		// failed to send the command length
#ifdef REMOTESHELLCLIENT_DEBUG
		::MessageBox(NULL,"Failed to send command length","RemoteShellClient",MB_OK);
#endif
		*pOutput = FALSE;
		return S_OK;
	}
	// return if command size is 0
	if(nCommandSize==0)
	{
		*pOutput = TRUE;
		return S_OK;
	}
	// then send the command to the remote server
	int nBufSize, nTotal, nSent;
	nTotal = 0;
	nSent = 0;
	while(nTotal<nCommandSize)
	{
		nBufSize = min(nCommandSize-nTotal,1024);
		nSent = ::send(m_socket,((const char*)pCommand)+nTotal,nBufSize,0);
		if(nSent==SOCKET_ERROR)
		{
			// failed to send the command
#ifdef REMOTESHELLCLIENT_DEBUG
			::MessageBox(NULL,"Failed to send command","RemoteShellClient",MB_OK);
#endif
			*pOutput = FALSE;
			return S_OK;
		}
		nTotal += nSent;
	}
	// then send the input length to the remote server
	// in a platform-independent way
	char pInputLen[4] =
	{
		(byte)(0x000000ff&nInputSize),
		(byte)(0x000000ff&(nInputSize>>8)),
		(byte)(0x000000ff&(nInputSize>>16)),
		(byte)(0x000000ff&(nInputSize>>24))
	};
	if(::send(m_socket,pInputLen,4,0)==SOCKET_ERROR)
	{
		// failed to send the input length
#ifdef REMOTESHELLCLIENT_DEBUG
		::MessageBox(NULL,"Failed to send input length","RemoteShellClient",MB_OK);
#endif
		*pOutput = FALSE;
		return S_OK;
	}
	// finally, send the input to the remote server
	nTotal = 0;
	nSent = 0;
	while(nTotal<nInputSize)
	{
		nBufSize = min(nInputSize-nTotal,1024);
		nSent = ::send(m_socket,((const char*)pInput)+nTotal,nBufSize,0);
		if(nSent==SOCKET_ERROR)
		{
			// failed to send input
#ifdef REMOTESHELLCLIENT_DEBUG
		::MessageBox(NULL,"Failed to send input","RemoteShellClient",MB_OK);
#endif
			*pOutput = FALSE;
			return S_OK;
		}
		nTotal += nSent;
	}
	// command and input successfully sent to the remote server
	*pOutput = TRUE;
	return S_OK;
}

// get the last error code
STDMETHODIMP CRemoteClient::GetLastError(long * pOutput)
{
	*pOutput = ::WSAGetLastError();
	return S_OK;
}

// receive a chunk of the output data from the remote server
STDMETHODIMP CRemoteClient::GetOutput(BSTR * pOutput)
{
	// first, receive the length of this chunk of output data
	// in a platform-independent way
	char pSize[4];
	int nTotal = 0;
	int nRead = 0;
	while(nTotal<4)
	{	
		nRead = ::recv(m_socket,pSize+nTotal,4-nTotal,0);
		if(nRead==SOCKET_ERROR) 
		{
			// failed to receive output length
#ifdef REMOTESHELLCLIENT_DEBUG
			::MessageBox(NULL,"Failed to receive data length","RemoteShellClient",MB_OK);
#endif 
			*pOutput = ::SysAllocString(L"");
			return S_OK;
		}
		nTotal += nRead;
	}
	// check if output length is valid
	int nSize = (pSize[0]&0x000000ff)|((pSize[1]&0x000000ff)<<8)|((pSize[2]&0x000000ff)<<16)|((pSize[3]&0x000000ff)<<24);
	if(nSize<0) 
	{
		// invalid output length
#ifdef REMOTESHELLCLIENT_DEBUG
		::MessageBox(NULL,"Invalid data length","RemoteShellClient",MB_OK);
#endif 
		*pOutput = ::SysAllocString(L"");
		return S_OK;
	}
	// check zero length output
	if(nSize==0) 
	{
		*pOutput = ::SysAllocString(L"");
		return S_OK;
	}
	// finally, receive the output chunk from the remote server
	char* pData = new char[nSize+1];
	nTotal = 0;
	nRead = 0;
	while(nTotal<nSize)
	{	
		nRead = ::recv(m_socket,pData+nTotal,nSize-nTotal,0);
		if(nRead==SOCKET_ERROR)
		{
			// failed to receive output data
#ifdef REMOTESHELLCLIENT_DEBUG
			::MessageBox(NULL,"Failed to receive data","RemoteShellClient",MB_OK);
#endif 
			delete []pData;
			*pOutput = ::SysAllocString(L"");
			return S_OK;			
		}
		nTotal += nRead;
	}
	// return the output data as a BSTR
	pData[nSize] = 0;
	unsigned short* pBstrData = (unsigned short*)new short[nSize+1];
	CharToWChar(pBstrData,pData);
	*pOutput = ::SysAllocString(pBstrData);
	delete []pData;
	delete []pBstrData;
	return S_OK;
}
