// RemoteClient.h : Declaration of the CRemoteClient

#ifndef __REMOTECLIENT_H_
#define __REMOTECLIENT_H_

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CRemoteClient
class ATL_NO_VTABLE CRemoteClient : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CRemoteClient, &CLSID_RemoteClient>,
	public IDispatchImpl<IRemoteClient, &IID_IRemoteClient, &LIBID_REMOTESHELLCLIENTLib>
{
	// the socket descriptor
	SOCKET m_socket;
public:
	CRemoteClient()
	{
		// initialize socket descriptor
		m_socket = INVALID_SOCKET;
	}

DECLARE_REGISTRY_RESOURCEID(IDR_REMOTECLIENT)

BEGIN_COM_MAP(CRemoteClient)
	COM_INTERFACE_ENTRY(IRemoteClient)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IRemoteClient
public:
	STDMETHOD(GetOutput)(/*[out, retval]*/ BSTR* pOutput);
	STDMETHOD(GetLastError)(/*[out, retval]*/ long* pOutput);
	STDMETHOD(ExecuteEx)(/*[in]*/ long pCommand, /*[in]*/ long nCommandSize, /*[in]*/ long pInput, /*[in]*/ long nInputSize, /*[out, retval]*/ BOOL* pOutput);
	STDMETHOD(Disconnect)();
	STDMETHOD(Execute)(/*[in]*/ BSTR strCommandLine, /*[in]*/ BSTR strInputData, /*[out, retval]*/ BOOL* pOutput);
	STDMETHOD(Connect)(/*[in]*/ BSTR strServerAddress, /*[in]*/ long nServerPort, /*[out, retval]*/ BOOL* pOutput);
};

#endif //__REMOTECLIENT_H_
