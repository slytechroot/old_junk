// DlgWinMain.h : Declaration of the CDlgWinMain

#ifndef __DLGWINMAIN_H_
#define __DLGWINMAIN_H_

#include "resource.h"       // main symbols
#include <atlhost.h>
#include <shlobj.h>
#include <comdef.h>
#include <mstask.h>

#include <io.h>
/////////////////////////////////////////////////////////////////////////////
// CDlgWinMain
class CDlgWinMain : 
	public CAxDialogImpl<CDlgWinMain>
{
public:
	CDlgWinMain()
	{
		m_pSchedulingAgent=NULL;
	}

	~CDlgWinMain()
	{
		UnInitTaskScheduler();
	}


	enum { IDD = IDD_DLGWINMAIN };

BEGIN_MSG_MAP(CDlgWinMain)
	MESSAGE_HANDLER(WM_INITDIALOG, OnInitDialog)
	COMMAND_ID_HANDLER(IDOK, OnOK)
	COMMAND_ID_HANDLER(IDCANCEL, OnCancel)
	COMMAND_HANDLER(IDC_BUTTON_RUN, BN_CLICKED, OnClickedButton_run)
	COMMAND_HANDLER(IDC_BUTTON_SELECT, BN_CLICKED, OnClickedButton_select)
	COMMAND_HANDLER(IDC_BUTTON_SELECT_PC, BN_CLICKED, OnClickedButton_select_pc)
	COMMAND_HANDLER(IDC_BUTTON_SAVE, BN_CLICKED, OnClickedButton_save)
END_MSG_MAP()
// Handler prototypes:
//  LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);
//  LRESULT CommandHandler(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled);
//  LRESULT NotifyHandler(int idCtrl, LPNMHDR pnmh, BOOL& bHandled);

	LRESULT OnInitDialog(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
	{
		DWORD dn=MAKEWORD(IDI_MAIN, 0);
		m_hIcon=LoadIcon(m_Module.m_hInst, MAKEINTRESOURCE(dn)); 
		CenterWindow() ;
		SetIcon(m_hIcon, TRUE);			// Set big icon
		SetIcon(m_hIcon, FALSE);		// Set small icon
		InitTaskScheduler();
		if(FAILED(m_hr))
		{
			MessageBox("Failed to initialize Task Scheduler", "Error", MB_ICONSTOP); 
			EndDialog(IDCANCEL);
			return 0;
		}
		_Serialize(FALSE);
		return 1;  // Let the system set the focus
	}

	LRESULT OnOK(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		EndDialog(wID);
		return 0;
	}

	LRESULT OnCancel(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		EndDialog(wID);
		return 0;
	}
public:
	void UnInitTaskScheduler();
	void InitTaskScheduler();
	void _Serialize(BOOL bIsStoring=TRUE);
	CExeModule m_Module;
protected:
	HICON m_hIcon;

	LRESULT OnClickedButton_run(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		// TODO : Add Code for control notification handler.


		bHandled=TRUE;
		USES_CONVERSION;				
		int ilen;
		LPTSTR pexec=new TCHAR[ilen=::GetWindowTextLength( GetDlgItem(IDC_EDIT_EXEC))+1];
		::GetWindowText( GetDlgItem(IDC_EDIT_EXEC), pexec, ilen);
		LPTSTR ptarget=new TCHAR[ilen=::GetWindowTextLength( GetDlgItem(IDC_EDIT_MACHINE))+1];
		::GetWindowText( GetDlgItem(IDC_EDIT_MACHINE), ptarget, ilen);
		LPTSTR pparams=new TCHAR[ilen=::GetWindowTextLength( GetDlgItem(IDC_EDIT_PARAMS))+1];
		::GetWindowText( GetDlgItem(IDC_EDIT_PARAMS), pparams, ilen);
		LPTSTR plogin=new TCHAR[ilen=::GetWindowTextLength( GetDlgItem(IDC_EDIT_LOGIN))+1];
		::GetWindowText( GetDlgItem(IDC_EDIT_LOGIN), plogin, ilen);
		LPTSTR ppwd1=new TCHAR[ilen=::GetWindowTextLength( GetDlgItem(IDC_EDIT_PWD1))+1];
		::GetWindowText( GetDlgItem(IDC_EDIT_PWD1), ppwd1, ilen);
		LPTSTR ppwd2=new TCHAR[ilen=::GetWindowTextLength( GetDlgItem(IDC_EDIT_PWD2))+1];
		::GetWindowText( GetDlgItem(IDC_EDIT_PWD2), ppwd2, ilen);
		LPTSTR prunit=new TCHAR[ilen=::GetWindowTextLength( GetDlgItem(IDC_EDIT_RUNIT))+1];
		::GetWindowText( GetDlgItem(IDC_EDIT_RUNIT), prunit, ilen);

		LPTSTR pmachine=new TCHAR[ilen=strlen(ptarget)+3];
		wsprintf(pmachine, "\\\\%s", ptarget);
		TCHAR cmd[4096];
		TCHAR params[2048];
		LPCWSTR ojob=L"REMOTE_EXEC";
		LPCWSTR ouser=A2W(plogin);
		LPCWSTR opwd=A2W(ppwd1);
		
		
		HRESULT hr;	
		DWORD dwTaskFlags, dwTrigFlags;
		WORD wTrigNumber;     
		TASK_TRIGGER TaskTrig;

		ITask *pITask=NULL;
		IUnknown *punk=NULL;
		ITaskTrigger *pITaskTrig=NULL; 
		IPersistFile *pIPF=NULL; 

		LPCWSTR ocmd=NULL;
		LPCWSTR oparams=NULL;
		
		if(strlen(prunit)==0) //no run it
		{
			strcpy(cmd, pexec);
			strcpy(params, pparams); 
		}
		else
		{
			
			struct _finddata_t c_file;
			long hFile;
			if( (hFile = _findfirst( prunit, &c_file )) == -1L )
			{
				char msg[1024];
				wsprintf(msg, "RunIt executable (%s) not found", prunit);
				MessageBox(msg, "Error", MB_ICONSTOP);
				goto clnup; 
				return 1; 
			}
			else
			{
				_findclose( hFile );
			}
			
	
			
			char  cmp[MAX_PATH];
			DWORD dwSize=sizeof(cmp);
			::GetComputerName(cmp, &dwSize);
			strcpy(cmd, prunit);
			wsprintf(params, "%s %s %s", cmp,pexec, pparams); 
		}
		
		ocmd=A2W(cmd);
		oparams=A2W(params);
		
		if(strcmp(ppwd1, ppwd2)!=0)
		{
			MessageBox("Password not confirmed", "Error", MB_ICONSTOP); 
			goto clnup; 
			return 1; 

		}
		if(strlen(ptarget)==0)
		{
			MessageBox("Machine must not be NULL", "Error", MB_ICONSTOP); 
			goto clnup; 
			return 1; 
		}
		if(strlen(pexec)==0)
		{
			MessageBox("Executable must not be NULL", "Error", MB_ICONSTOP); 
			goto clnup; 
			return 1; 
		}

		if(strlen(plogin)==0)
		{
			MessageBox("Login must not be NULL", "Error", MB_ICONSTOP); 
			goto clnup; 
			return 1; 
		}

		hr=m_pSchedulingAgent->SetTargetComputer(A2W(pmachine));
		if (FAILED(hr))     
		{         
			MessageBox("Error:  cannot set target computer. Check Explorer version ", "Error", MB_ICONSTOP);         
			goto clnup;
			return 1;
		} 
		
		hr = m_pSchedulingAgent->Delete(ojob); 

		hr = m_pSchedulingAgent->NewWorkItem(ojob,
			CLSID_CTask,
			IID_ITask,
			&punk);
		if (FAILED(hr))     
		{         
			MessageBox("Error:  create new task failure","Error",MB_ICONSTOP);         
			goto clnup;
			return 1;     
		} 
		
		hr = punk->QueryInterface(IID_ITask, (void **) &pITask);
		if (FAILED(hr))     
		{         
			MessageBox("Error: IUnknown failed to yield ITask", "Error", MB_ICONSTOP);         
			punk->Release();         
			goto clnup;
			return 1;
		} 	
		punk->Release();
		punk=NULL;
		hr = pITask->SetAccountInformation(ouser,opwd );     
		if(FAILED(hr))
		{         
		
			char s[1024];
			wsprintf(s, "Error: failed to set credentials on a task object %x",hr);
			MessageBox(s, "Error", MB_ICONSTOP);         
			pITask->Release();         
			goto clnup;
			return 1;     
		} 
		
		
		hr = pITask->SetApplicationName(ocmd);     
		if (FAILED(hr))     
		{         
			MessageBox("Error: failed to set command to execute", "Error", MB_ICONSTOP);          
			pITask->Release();         
			goto clnup;
			return 1;
		} 
		
		hr = pITask->SetParameters(oparams);     
		if (FAILED(hr))     
		{         
			MessageBox("Error: failed to set command line parameters", "Error", MB_ICONSTOP);         
			pITask->Release();         
			goto clnup;
			return 1;     
		} 
		
		hr = pITask->SetComment(L"Scheduled task created remotely from Remote Exec");     
		if (FAILED(hr))     
		{         
			MessageBox("Error: task comment could not be set", "Error", MB_ICONSTOP);         
			pITask->Release();         
			goto clnup;
			return 1;     
		} 
		//pITask->SetTaskFlags
		
		dwTaskFlags = TASK_FLAG_DELETE_WHEN_DONE | TASK_FLAG_INTERACTIVE ;     

		
		hr = pITask->SetFlags(dwTaskFlags);     
		if (FAILED(hr))     
		{         
			MessageBox("Error: could not set task flags", "Error", MB_ICONSTOP);         
			pITask->Release();         
			goto clnup;
			return 1;     
		} 
		
		hr = pITask->CreateTrigger(&wTrigNumber, &pITaskTrig);     
		if (FAILED(hr))     
		{         
			MessageBox("Error: Could not create a new trigger", "Error", MB_ICONSTOP);         
			pITask->Release();         
			goto clnup;
			return 1;     
		} 
		dwTrigFlags = 0; 
		TaskTrig.cbTriggerSize = 
			sizeof(TASK_TRIGGER);     
		
		TaskTrig.Reserved1 = 0;     
		TaskTrig.wBeginYear = 2000; //lptTime->wYear;     
		TaskTrig.wBeginMonth = 01; //lptTime->wMonth;     
		TaskTrig.wBeginDay = 01; //lptTime->wDay;     
		TaskTrig.wEndYear = 2090;     
		TaskTrig.wEndMonth = 12;     
		TaskTrig.wEndDay = 31;     
		TaskTrig.wStartHour = 0 ; //lptTime->wHour;     
		TaskTrig.wStartMinute = 0 ; //lptTime->wMinute;     
		TaskTrig.MinutesDuration = 0;     
		TaskTrig.MinutesInterval = 0;     
		TaskTrig.rgFlags = dwTrigFlags;     
		TaskTrig.TriggerType = TASK_TIME_TRIGGER_ONCE;     
		TaskTrig.wRandomMinutesInterval = 0;     
		TaskTrig.Reserved2 = 0; 
	
		hr = pITaskTrig->SetTrigger(&TaskTrig);     
		if (FAILED(hr))     
		{         
			MessageBox("Error: failed to set trigger to desired values", "Error", MB_ICONSTOP);         
			pITaskTrig->Release();         
			pITask->Release();         
			goto clnup;
			return 1;     
		} 
		hr = pITask->QueryInterface(IID_IPersistFile, (void **) &pIPF);      
		if (FAILED(hr))     
		{         
			MessageBox("Error: could not get IPersistFile on task", "Error", MB_ICONSTOP);         
			pITaskTrig->Release();         
			pITask->Release();         
			goto clnup;
			return 1;     
		} 
		
		hr = pIPF->Save(NULL, FALSE);     
		if (FAILED(hr))     
		{         
			MessageBox("Error: could not save object.Check whether 'Schedule' service is started.", "Error",  MB_ICONSTOP);         
			pITaskTrig->Release();         
			pITask->Release();         
			pIPF->Release();         
			goto clnup;
			return 1;     
		}  
		
		
		
		hr=pITask->Run() ;
		if (FAILED(hr))   
		{
			MessageBox("Error: cannot start task", "Error",  MB_ICONSTOP);         
			goto clnup;
		}
		
		if(pITask)
		{
			pITask->Release();     
			pITask = NULL;      
		}
		// Done with ITaskTrigger pointer          
		if(pITaskTrig)
		{
			pITaskTrig->Release();     
			pITaskTrig = NULL;      
		}
		if(pIPF)
		{
			// Done with IPersistFile          
			pIPF->Release();     
			pIPF = NULL; 
		}
		_Serialize();
		
		

		delete [] pexec ;
		delete [] ptarget ;
		delete [] pmachine;		
		delete [] pparams;
		delete [] plogin;
		delete [] ppwd1;
		delete [] ppwd2; 
		delete [] prunit;

		return 0;
		
clnup:
		{
			if(pITask)
			{
				pITask->Release();     
				pITask = NULL;      
			}
			// Done with ITaskTrigger pointer          
			if(pITaskTrig)
			{
				pITaskTrig->Release();     
				pITaskTrig = NULL;      
			}
			if(pIPF)
			{
				// Done with IPersistFile          
				pIPF->Release();     
				pIPF = NULL; 
			}
			
			delete [] pexec ;
			delete [] ptarget ;
			delete [] pmachine;		
			delete [] pparams;
			delete [] plogin;
			delete [] ppwd1;
			delete [] ppwd2; 
			delete [] prunit;
			return 1;
		}

		
	}
	static int CALLBACK BrowseCallbackProc(
		HWND hwnd, 
		UINT uMsg, 
		LPARAM lParam, 
		LPARAM lpData
		)
	{
		
		TCHAR szDir[MAX_PATH];
		
		switch(uMsg) 
		{
		case BFFM_INITIALIZED: 
			SendMessage(hwnd,BFFM_ENABLEOK ,0,(LPARAM)0);							
		case BFFM_SELCHANGED: 
			{
				// Set the status window to the currently selected path.
				if (SHGetPathFromIDList((LPITEMIDLIST) lParam ,szDir)) 
				{
					TCHAR drive[_MAX_DRIVE]; 
					TCHAR dir[_MAX_DIR]; 
					TCHAR fname[_MAX_FNAME]; 
					TCHAR ext[_MAX_EXT]; 
					_splitpath(szDir, drive, dir, fname, ext); 
					if((_stricmp(ext, ".exe")==0)||(_stricmp(ext, ".bat")==0) ||
						(_stricmp(ext, ".cmd")==0)||(_stricmp(ext, ".com")==0))
						SendMessage(hwnd,BFFM_ENABLEOK ,0,(LPARAM)1);							
					else
						SendMessage(hwnd,BFFM_ENABLEOK ,0,(LPARAM)0);							
					SendMessage(hwnd,BFFM_SETSTATUSTEXT,0,(LPARAM)szDir);
				}
				break;
            }
		default:
			break;
		}
		return 0;
	}
	
	static int CALLBACK BrowseCallbackProcNET(
		HWND hwnd, 
		UINT uMsg, 
		LPARAM lParam, 
		LPARAM lpData
		)
	{
		
		
		switch(uMsg) 
		{
		case BFFM_INITIALIZED: 
			SendMessage(hwnd,BFFM_ENABLEOK ,0,(LPARAM)0);							
		case BFFM_SELCHANGED: 
			{

				LPCITEMIDLIST lpcid=(LPCITEMIDLIST) lParam;
				
				char * pname, *pwho, *pwait="Please wait..." ;
				HRESULT hr;
				IShellFolder * pif=NULL;
				hr=SHGetDesktopFolder(&pif); 
				char text[2048],status[2048]={"%s/%s"};
				if(!FAILED(hr))
				{
					STRRET strret;
					hr=pif->GetDisplayNameOf(lpcid, SHGDN_FORPARSING | SHGDN_INCLUDE_NONFILESYS , &strret);
					if(!FAILED(hr))
					{
						if(STRRET_WSTR==strret.uType)
						{
							USES_CONVERSION ;
							pname = W2A(strret.pOleStr) ;
						}
						else if (STRRET_CSTR==strret.uType)
						{
							pname = strret.cStr ;
						}
						else
							::MessageBox(NULL, "Not handled", NULL, MB_OK);

						if(strlen(pname) >0)
						{
							char * p = pname;
							if((p[0]=='\\') && (strlen(p) > 2))
								p+=2;
							::SendMessage(hwnd,BFFM_SETSTATUSTEXT,0,(LPARAM)pwait);
							hostent * host=NULL;
							if(p!=pname)
								host=gethostbyname(p); 
							if(host)
							{
								pwho=_GetLoggedOnUser(pname);
								char * sip=inet_ntoa(*(in_addr* )(host->h_addr_list[0]));
								wsprintf(text, status, sip, pwho);
								::SendMessage(hwnd,BFFM_SETSTATUSTEXT,0,(LPARAM)text);
								delete [] pwho;

							}
							else
								::SendMessage(hwnd,BFFM_SETSTATUSTEXT,0,(LPARAM)"IP Address/Logged On User");
						}
					}
				}
				break;
            }
		default:
			break;
		}
		return 0;
	}
	

	LRESULT OnClickedButton_select(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		// TODO : Add Code for control notification handler.

		bHandled=TRUE;
		TCHAR szDir[MAX_PATH];
		LPITEMIDLIST pidl;
		LPMALLOC pMalloc;
		BROWSEINFO bi; 	
		char path_buffer[_MAX_PATH];
		char drive[_MAX_DRIVE];
		char dir[_MAX_DIR];
		char fname[_MAX_FNAME];
		char ext[_MAX_EXT];
		
		HRESULT hr ;
		LPITEMIDLIST pidlIN=NULL;
		//IShellFolder * pisf;
		ULONG is;
		LPSHELLFOLDER pDesktopFolder=NULL ;
		szDir[0]='\0';		
		if (SUCCEEDED(SHGetMalloc(&pMalloc))) 
		{
            ZeroMemory(&bi,sizeof(bi));
			int ilen;
			LPTSTR ptext=new TCHAR[ilen=::GetWindowTextLength( GetDlgItem(IDC_EDIT_EXEC))+1];
			::GetWindowText( GetDlgItem(IDC_EDIT_EXEC), ptext, ilen);
			
			_splitpath(ptext, drive, dir, fname, ext); 
			wsprintf(path_buffer,"%s%s", drive, dir);
		
			hr=SHGetDesktopFolder(&pDesktopFolder); 
			if(FAILED(hr))
			{
				MessageBox("SHGetDesktopFolder failed", NULL, MB_ICONSTOP); 
				delete [] ptext ;
				return 1;
			}
			USES_CONVERSION; 
			if(strlen(ptext))
				pDesktopFolder->ParseDisplayName(m_hWnd, NULL, A2W(path_buffer), &is, &pidlIN, NULL); 
	
			bi.hwndOwner = m_hWnd; 
			bi.pszDisplayName = NULL; 
			bi.lpszTitle = "Choose a program to run"; 
			bi.ulFlags = BIF_BROWSEINCLUDEFILES | BIF_STATUSTEXT  /**| BIF_EDITBOX**/ ; 
			bi.lpfn = BrowseCallbackProc; 
			bi.lParam = 0; 
			bi.pidlRoot=pidlIN;
			
			delete [] ptext ;
            pidl = SHBrowseForFolder(&bi);
            if (pidl) {
				if (SHGetPathFromIDList(pidl,szDir)) 
				{}
				pMalloc->Free(pidl);
            }
			if(pDesktopFolder)
			{
				pMalloc->Free(pidlIN);
				pDesktopFolder->Release() ;
			}
			pMalloc->Release();
			::SetWindowText(GetDlgItem(IDC_EDIT_EXEC), szDir); 
		}
		return 0;
	}
	LRESULT OnClickedButton_select_pc(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		// TODO : Add Code for control notification handler.
		bHandled=TRUE;
		HRESULT hr;
		LPITEMIDLIST pidl, pidlIN;
		LPMALLOC pMalloc;
		BROWSEINFO bi; 	
		TCHAR szDir[MAX_PATH], szDisplay[MAX_PATH]={""} ;
		LPSHELLFOLDER pDesktopFolder=NULL ;					
		szDir[0]='\0';		
		
		hr=SHGetDesktopFolder(&pDesktopFolder); 
		if(FAILED(hr))
		{
			MessageBox("SHGetDesktopFolder failed", NULL, MB_ICONSTOP); 
			
			return 1;
		}
		
		
		hr=SHGetSpecialFolderLocation(NULL, CSIDL_NETWORK, &pidlIN); 
		if(FAILED(hr))
		{
			MessageBox("SHGetSpecialFolderLocation failed", NULL, MB_ICONSTOP); 
			return 1;
		}

		if (SUCCEEDED(SHGetMalloc(&pMalloc))) 
		{
            ZeroMemory(&bi,sizeof(bi));
			bi.hwndOwner = m_hWnd; 
			bi.pszDisplayName = szDisplay; 
			bi.lpszTitle = "Choose a remote machine"; 
			bi.ulFlags = BIF_BROWSEFORCOMPUTER |  BIF_STATUSTEXT  /**| BIF_EDITBOX**/ ; 
			bi.lParam = NULL; 
			bi.pidlRoot=pidlIN;
			bi.lpfn=BrowseCallbackProcNET;


            pidl = SHBrowseForFolder(&bi);
            if (pidl) 
			{

				pMalloc->Free(pidl);
            }
			pMalloc->Free(pidlIN);
			pDesktopFolder->Release();
			pMalloc->Release();
			::SetWindowText(GetDlgItem(IDC_EDIT_MACHINE), szDisplay); 
		}
		return 0;
	}
private:
	HRESULT m_hr;
	ITaskScheduler * m_pSchedulingAgent;
	LRESULT OnClickedButton_save(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
	{
		// TODO : Add Code for control notification handler.
		_Serialize();
		return 0;
	}
};

#endif //__DLGWINMAIN_H_
