//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by RemExec.rc
//
#define IDS_PROJNAME                    100
#define IDR_RemExec                     100
#define IDD_DLGWINMAIN                  103
#define IDC_BUTTON_RUN                  201
#define IDC_BUTTON_SELECT               202
#define IDC_EDIT_EXEC                   203
#define IDI_MAIN                        204
#define IDC_BUTTON_SELECT_PC            204
#define IDC_EDIT_MACHINE                205
#define IDC_EDIT_PARAMS                 206
#define IDC_EDIT_LOGIN                  208
#define IDC_EDIT_PWD1                   209
#define IDC_EDIT_PWD2                   210
#define IDC_BUTTON_SAVE                 211
#define IDC_EDIT_RUNIT                  212

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        205
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         213
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
