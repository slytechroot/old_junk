// DlgWinMain.cpp : Implementation of CDlgWinMain
#include "stdafx.h"
#include "DlgWinMain.h"

/////////////////////////////////////////////////////////////////////////////
// CDlgWinMain


void CDlgWinMain::InitTaskScheduler()
{
	m_hr = CoCreateInstance( CLSID_CSchedulingAgent, 
            NULL, 
            CLSCTX_INPROC_SERVER, 
            IID_ITaskScheduler, 
            (LPVOID*)&m_pSchedulingAgent);
}

void CDlgWinMain::UnInitTaskScheduler()
{
	
	if (m_pSchedulingAgent!=NULL)
	{
		m_hr=m_pSchedulingAgent->Release() ;
		m_pSchedulingAgent=NULL;
	}
}
void CDlgWinMain::_Serialize(BOOL bIsStoring)
{

	
	if (bIsStoring)
	{
		int ilen;
		LPTSTR pexec=new TCHAR[ilen=::GetWindowTextLength( GetDlgItem(IDC_EDIT_EXEC))+1];
		::GetWindowText( GetDlgItem(IDC_EDIT_EXEC), pexec, ilen);
		LPTSTR ptarget=new TCHAR[ilen=::GetWindowTextLength( GetDlgItem(IDC_EDIT_MACHINE))+1];
		::GetWindowText( GetDlgItem(IDC_EDIT_MACHINE), ptarget, ilen);
		LPTSTR pparams=new TCHAR[ilen=::GetWindowTextLength( GetDlgItem(IDC_EDIT_PARAMS))+1];
		::GetWindowText( GetDlgItem(IDC_EDIT_PARAMS), pparams, ilen);
		LPTSTR plogin=new TCHAR[ilen=::GetWindowTextLength( GetDlgItem(IDC_EDIT_LOGIN))+1];
		::GetWindowText( GetDlgItem(IDC_EDIT_LOGIN), plogin, ilen);
		LPTSTR ppwd1=new TCHAR[ilen=::GetWindowTextLength( GetDlgItem(IDC_EDIT_PWD1))+1];
		::GetWindowText( GetDlgItem(IDC_EDIT_PWD1), ppwd1, ilen);
		LPTSTR ppwd2=new TCHAR[ilen=::GetWindowTextLength( GetDlgItem(IDC_EDIT_PWD2))+1];
		::GetWindowText( GetDlgItem(IDC_EDIT_PWD2), ppwd2, ilen);
		LPTSTR prunit=new TCHAR[ilen=::GetWindowTextLength( GetDlgItem(IDC_EDIT_RUNIT))+1];
		::GetWindowText( GetDlgItem(IDC_EDIT_RUNIT), prunit, ilen);


		_WriteProfileString("Serialize", "exec", pexec);
		_WriteProfileString("Serialize", "target", ptarget);
		_WriteProfileString("Serialize", "params", pparams);
		_WriteProfileString("Serialize", "login", plogin);
		_WriteProfileString("Serialize", "pwd", ppwd1);
		_WriteProfileString("Serialize", "runit", prunit);

		delete []pexec;
		delete []ptarget;
		delete []pparams;
		delete []plogin;
		delete []ppwd1;
		delete []ppwd2;
		delete []prunit;
	}
	else
	{

		LPTSTR pexec=_GetProfileString("Serialize", "exec", "");
		::SetWindowText( GetDlgItem(IDC_EDIT_EXEC), pexec);
		LPTSTR ptarget=_GetProfileString("Serialize", "target", "");
		::SetWindowText( GetDlgItem(IDC_EDIT_MACHINE), ptarget);
		LPTSTR pparams=_GetProfileString("Serialize", "params", "");
		::SetWindowText( GetDlgItem(IDC_EDIT_PARAMS), pparams);
		LPTSTR plogin=_GetProfileString("Serialize", "login", "");
		::SetWindowText( GetDlgItem(IDC_EDIT_LOGIN), plogin );
		LPTSTR ppwd1=_GetProfileString("Serialize", "pwd", "");
		::SetWindowText( GetDlgItem(IDC_EDIT_PWD1), ppwd1);
		::SetWindowText( GetDlgItem(IDC_EDIT_PWD2), ppwd1);
		LPTSTR prunit=_GetProfileString("Serialize", "runit", "");
		::SetWindowText( GetDlgItem(IDC_EDIT_RUNIT), prunit);
		
		delete []pexec;
		delete []ptarget;
		delete []pparams;
		delete []plogin;
		delete []ppwd1;
		delete []prunit;
	}
}
