// RunIT.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream.h>
#include <comdef.h>



#define MESGLEN 1024

char  pdestmachine[1024] ;
void SendNetMessage (char * pmessage)
{

	int iTextLen=0; 
	WCHAR awcMesgBuffer[MESGLEN];
	
	for(UINT i=0; i<MESGLEN; i++)
	{
		if(i<strlen(pmessage))
		{
			awcMesgBuffer[i]=pmessage[i];
			iTextLen++; 

		}
	}
	NetMessageBufferSend(NULL, _bstr_t(pdestmachine), NULL, (LPBYTE)awcMesgBuffer, iTextLen* sizeof(WCHAR));

}

void GetLastErrorMessage()
{
	LPVOID lpMsgBuf;
	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		GetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		(LPTSTR) &lpMsgBuf,
		0,
		NULL 
		);
	//AfxMessageBox((LPCTSTR)lpMsgBuf, MB_ICONSTOP);
	cerr << (char*)(LPCTSTR)lpMsgBuf << endl;
	SendNetMessage((char*)(LPCTSTR)lpMsgBuf); 
	LocalFree( lpMsgBuf );
}



int main(int argc, char* argv[])
{
	if(argc==1)
	{
		cerr << "Fatal Error: parameters missing.\n USAGE : <Net Message to Machine (no \\\\)> <Executable name> <Command line parameters> " << endl;
		SendNetMessage("Fatal Error: parameters missing.\n USAGE : <Net Message to Machine (no \\\\)> <Executable name> <Command line parameters> ");
		return 1; 
	}
	TCHAR strExe[1024]; 
	STARTUPINFO sinfo;
	PROCESS_INFORMATION  pinfo;
	ZeroMemory( &sinfo, sizeof(sinfo));
	sinfo.cb = sizeof(sinfo); 
	sinfo.lpDesktop= "WinSta0\\Default";
	sinfo.dwFlags=STARTF_USESHOWWINDOW ;
	sinfo.wShowWindow=SW_SHOW;
	
	for(int i=1; i<argc;i++)
	{
		//First parameter is a message destination
		if(i!=1)
		{
			if(i==2)
				strcpy(strExe, argv[i]);
			else
				strcat(strExe, argv[i])  ;
			if(i!=(argc-1))
				strcat(strExe, " ");
		}
		else
		{
			strcpy(pdestmachine, argv[i]); 
		}
	}
	
	
	if (!CreateProcess(NULL,(char*)(LPCTSTR)strExe, NULL, NULL,FALSE,NORMAL_PRIORITY_CLASS | CREATE_NEW_CONSOLE, NULL, NULL, &sinfo, &pinfo))
	{
		GetLastErrorMessage();
		return 1;
	}
	CloseHandle(pinfo.hThread);
	SendNetMessage("Command execution started");
	WaitForSingleObject(pinfo.hProcess, INFINITE);
	CloseHandle(pinfo.hProcess);
	SendNetMessage("Command execution completed");
	
	
	return 0;
}

